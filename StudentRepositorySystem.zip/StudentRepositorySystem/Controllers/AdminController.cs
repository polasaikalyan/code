﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRepositorySystem.Models;


namespace StudentRepositorySystem.Controllers
{
    public class AdminController : Controller
    {
        private masterEntities db = new masterEntities();

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(AdminLoginDetail admin)
        {
            var isAdminIdExists = db.AdminLoginDetails.Where(a => a.adminid == admin.adminid).SingleOrDefault();
            if (isAdminIdExists != null)
            {
                if (isAdminIdExists.adminpassword == admin.adminpassword)
                {
                    Session["usertype"] = "admin";
                    Session["studentid"] = isAdminIdExists.adminid;
                    Session["username"] = isAdminIdExists.adminid;
                    Session["imagepath"] = "~/Images/Admin-icon.png";
                    return RedirectToAction("DashBoard", "Admin");
                }
                else { ModelState.AddModelError("adminpassword", "password not matched"); }
            }
            else { ModelState.AddModelError("adminid", "Id not exists"); }
            return View();
        }

        // GET: Admin
        public ActionResult DashBoard()
        {
            bool isAuth = isAuthorized();
            if (isAuth)
            {
                int studentCount = db.StudentDetails.Count();
                int noofjobApplication = db.JobsApplieds.Count();
                ViewBag.studentCount = studentCount;
                ViewBag.jobsCount = noofjobApplication;
                return View();
            }
            return View("UnAuthorized");
        }

        public ActionResult AddNewJob()
        {
            bool isAuth = isAuthorized();
            if (isAuth)
            {
                return View();
            }
            return View("UnAuthorized");
        }

        [HttpPost]
        public ActionResult AddNewJob(Job job)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    job.createddate = DateTime.Now.Date;
                    db.Jobs.Add(job);
                    db.SaveChanges();
                }
                return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                return Json(new { status = "error", msg = e.Message.ToString() }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult ManageJobs()
        {
            //var jobs = db.Jobs.ToList();
            return View();
        }

        [HttpGet]
        public ActionResult GetJobs()
        {
            var res = (from a in db.Jobs select new { jobid = a.jobid, jobtitle = a.jobtitle, companytitle = a.companytitle, jobdescription = a.jobdescription, createddate = a.createddate }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetDetails(int? jobid)
        {
            return Json(new { status = "success", data = jobid }, JsonRequestBehavior.AllowGet); ;
        }

        public ActionResult GetDetailsByJobId(int? jobid)
        {
            var jobdata = db.Jobs.Find(jobid);
            return View(jobdata);
            //return Json(new { status = "success", data = jobdata }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetDetailsByJobId(Job job)
        {
            db.Entry(job).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("ManageJobs");
        }

        [HttpPost]
        public ActionResult SaveChangedJobDetails(Job job)
        {
            db.Entry(job).State = EntityState.Modified;
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult DeleteJob(int? jobid)
        {
            var getjobbyid = db.Jobs.Find(jobid);
            db.Jobs.Remove(getjobbyid);
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ManageStudents()
        {
            //var allstudents = db.StudentDetails.ToList();
            return View();
        }

        public ActionResult DeleteStudentById(int? studentid)
        {
            var student = db.StudentDetails.Find(studentid);
            db.StudentDetails.Remove(student);
            string pathname = studentid + ".jpg";
            string fullPath = Request.MapPath("~/Images/" + pathname);
            if (System.IO.File.Exists(fullPath))
            {
                System.IO.File.Delete(fullPath);
            }
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetStudents()
        {
            var res = (from a in db.StudentDetails select new { studentid = a.studentid, studentname = a.studentname, age = a.age, gender = a.gender, dob = a.dob, mobilenumber = a.mobileno, address = a.address }).ToList();
            return Json(new { data = res }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetStuDetails(int? studentid)
        {
            return Json(new { status = "success", data = studentid }, JsonRequestBehavior.AllowGet); ;
        }

        public ActionResult GetStudentDetailsById(int? studentid)
        {
            StudentDetail student = db.StudentDetails.Where(a => a.studentid == studentid).FirstOrDefault();
            ViewBag.dob = student.dob;
            return View(student);
            //return Json(new { status = "success", data=student }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetStudentDetailsById(StudentDetail student)
        {
            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            //return RedirectToAction("ManageStudents");
            return Json(new { status = "success", data = student }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult EditStudentDetails(StudentDetail student)
        {
            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
        }

        public bool isAuthorized()
        {
            bool auth = false;
            if (Session["usertype"].ToString() == "admin")
            {
                auth = true;
            }
            return auth;
        }    
    }
}