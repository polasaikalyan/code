﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StudentRepositorySystem.Models;

namespace StudentRepositorySystem.Controllers
{
    public class JobsController : Controller
    {
        private masterEntities db = new masterEntities();

        // GET: Jobs
        public ActionResult DashBoard()
        {
            Session["usertype"] = "jobs";
            int jobsCount = db.Jobs.Count();
            ViewBag.jobsCount = jobsCount;
            return View();
        }

        public ActionResult ApplyJobs()
        {
            //var jobs = db.Jobs.ToList();
            return View();
        }

        [HttpGet]
        public ActionResult GetJobs()
        {
            var jobs = (from a in db.Jobs select new { jobid = a.jobid, jobtitle = a.jobtitle, companytitle = a.companytitle, jobdescription = a.jobdescription, createdon = a.createddate }).ToList();
            return Json(new { data = jobs }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult jobForm(int? id)
        {
            var job = db.Jobs.Find(id);
            return View(job);
        }

        public JsonResult GetDetailsByID(int? id)
        {
            var studentdetails = db.StudentDetails.Find(id);
            if (studentdetails != null)
            {
                //return Json(new { data=studentdetails }, JsonRequestBehavior.AllowGet);
                return Json(new { status = "success", studentname = studentdetails.studentname, age = studentdetails.age, address = studentdetails.address, mobileno = studentdetails.mobileno, dob = studentdetails.dob }, JsonRequestBehavior.AllowGet);
            }
            return Json(new { status = "error", msg = "Id Not Found" }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SaveJobApplyDetails(int? id, int? jobid)
        {
            var IsAlreadyApplied = db.JobsApplieds.Where(a => a.studentid == id && a.jobid == jobid).ToList();
            if (IsAlreadyApplied.Count == 0)
            {
                try
                {
                    JobsApplied newjob = new JobsApplied()
                    {
                        jobid = jobid,
                        studentid = id,
                        applieddate = DateTime.Now.Date
                    };
                    db.JobsApplieds.Add(newjob);
                    db.SaveChanges();
                    return Json(new { status = "success" }, JsonRequestBehavior.AllowGet);
                }
                catch (Exception e)
                {
                    return Json(new { status = "failed", error = e.Message.ToString() }, JsonRequestBehavior.AllowGet);
                }
            }
            else
            {
                return Json(new { status = "failed", error = "This Job is Already applied by this id" }, JsonRequestBehavior.AllowGet);
            }
        }

        public bool isAuthorized()
        {
            bool auth = false;
            if (Session["usertype"].ToString() == "jobs")
            {
                auth = true;
            }
            return auth;
        }
    }
}